module.exports = {
    default: {
      requireModule: ['jest'],
      require: ['stepDefinations/*.js', 'support/*.js'],
      format: ['progress-bar', 'html:cucumber-report.html']
    }
  };