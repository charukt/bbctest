const { Given,When,Then } = require('@cucumber/cucumber')
const { expect } = require('expect');
const axi = require('axios');
const assert = require('assert');

let response;
let responseTime;



When ('Get request to {string}', async function (url) {
try{
    console.log(url);
    const startTime = new Date();
    response = await axi.get(url);
    const endTime = new Date();
    responseTime = endTime - startTime;
} catch (error) {
    console.error('Error fetching the URL:');
}

});
         
Then ('HTTP status code {int}', function (statuscode) {
    expect(response.status).toBe(statuscode);         
});


Then ('verify that the response timeof the request is below {int} milliseconds', 
function (maximumTime) {
    expect(responseTime).toBeLessThan(maximumTime);
});

Then('Verify if the “id” field is never null or empty\\(“”) for 14 items present in the data array', function () {

    for(key of response.data.data){
        expect(key.id).not.toBeNull;
        expect(key.id).not.toBe("");
    }
      
});

Then('verify that the {string} field for every track is always “music”', function (string) {

    for(key of response.data.data){
        expect(key[string]).toBe("music");
    }
  });


Then('verify that the “primary” field in “title_list” is never null or empty\\(“”) for any track', function () {
    
    for(key of response.data.data){
        expect(key.title_list.primary).not.toBe(null);
        expect(key.title_list.primary).not.toBe("");
    }  

    });

Then('verify that only one track in the list has “now_playing” field in “offset” as true', function () {
    
    let true_count=0;
    for(key of response.data.data){
        if(key.offset.now_playing.toString() == "true"){true_count=true_count+1;}
    }
        assert(true_count === 1, "Exactly "+true_count+ " track have 'now_playing' set to true in its offset");
        expect(true_count).toBe(1);
    });

Then('the response headers, verify the “Date” value', function () {
        
    expect(response.Date).not.toBe(null);
    const currentDate = new Date();
    const headerDate =   new Date(response.headers.date);
    const timeDifference = Math.abs(currentDate.getTime() - headerDate.getTime());

    assert(
        timeDifference <= 5000,
        "Response date differs from current date by " + timeDifference + "ms, which exceeds the expected difference"
      );
   
});